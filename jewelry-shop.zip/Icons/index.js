export { default as ArrowBack } from "./ArrowBack";
export { default as Instagram } from "./Instagram";
export { default as Telegram } from "./Telegram";
export { default as Mozaic } from "./Mozaic";

