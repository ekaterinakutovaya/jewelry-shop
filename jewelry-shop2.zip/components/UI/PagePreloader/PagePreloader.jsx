import React from 'react';

import styles from "./PagePreloader.module.scss";
import { LogoIcon } from "components";

const PagePreloader = ({header}) => {

  return (
    <div className={styles.preloader}>
      <LogoIcon color={header.length && header[0].textColor} />
    </div>
  );
};

export default PagePreloader;